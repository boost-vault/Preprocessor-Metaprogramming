#ifndef BOOST_FORWARDER_CTOR_TEMPLATE_INCLUDED
#define BOOST_FORWARDER_CTOR_TEMPLATE_INCLUDED
    #include <boost/preprocessor/iterate.hpp>
    #include <boost/preprocessor/repetition/enum_params.hpp>
    #include <boost/preprocessor/repetition/enum_binary_params.hpp>
    #define BOOST_FORWARDER_CTOR_TEMPLATE_FILE_ITER() \
      <boost/forwarder/detail/ctor_template.hpp> \
      /**/
#endif

