//xform seq to tuple of identity function apps.
#ifndef BOOST_FORWARDER_SEQ_TO_IDENTITY_TUPLE_INCLUDED
#define BOOST_FORWARDER_SEQ_TO_IDENTITY_TUPLE_INCLUDED
/*Acknowlegements:
 *  2008-09-02:
 *    Thanks to Paul Mensonides for suggestions in:
 *      http://article.gmane.org/gmane.comp.lib.boost.devel/147430
 */
#include "boost/forwarder/identity.hpp"
#include <boost/preprocessor/seq/transform.hpp>
#include <boost/preprocessor/seq/to_tuple.hpp>
#define BOOST_FWD_APPLY_IDENTITY(rep, _, elem) \
  boost::forwarder::identity(elem) \
  /**/
#define BOOST_FWD_SEQ_TO_IDENTITY_TUPLE(seq) \
  BOOST_PP_SEQ_TO_TUPLE \
  ( BOOST_PP_SEQ_TRANSFORM(BOOST_FWD_APPLY_IDENTITY, ~, seq) \
  ) \
  /**/
#endif
