//define identity functions to effectively cast temporary to const T&.
#ifndef BOOST_FORWARDER_IDENTITY_INCLUDED
#define BOOST_FORWARDER_IDENTITY_INCLUDED
namespace boost
{
namespace forwarder
 /**@brief
  *  Define identity template functions as described by 
  *  Paul Mensonides in the following post:
  *    http://article.gmane.org/gmane.comp.lib.boost.devel/147413
  *  where identity definitions are just after:
  *    template<class T> class smart_ptr {
  *    ...
  *    };
  */
{

  template<class T> inline T& identity(T& x) 
  {
      return x;
  }
  template<class T> inline const T& identity(const T& x)
   /**@brief
    *  If this is applied to temporary (e.g. if T is int and
    *  this is applied to 1), then compiler converts the 1
    *  to const int&.  IOW, this effectively does:
    *    (const int&)1
    *  when invoked on argument to function, f(int), as follows:
    *    f(identity(1))
    *
    * @reference:
    *  http://article.gmane.org/gmane.comp.lib.boost.devel/147413
    */
  {
      return x;
  }
  template<class T> inline volatile T& identity(volatile T& x) 
  {
      return x;
  }
  template<class T> inline const volatile T& identity(const volatile T& x) 
  {
      return x;
  }
  
}}//exit boost::forwarder
#endif
