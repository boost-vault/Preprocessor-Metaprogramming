/**@brief
 *  Provide macro for generating a number of templated CTOR's
 *  which possibly do something (e.g. pass args to base clase)
 *  using macro, BOOST_FORWARDER_CTOR_TEMPLATE_BASE_TYPE(N).
 * @input_conditions:
 *  1) BOOST_FORWARDER_CTOR_TEMPLATE_THIS_TYPE is name of current class.
 *  2) BOOST_FORWARDER_CTOR_TEMPLATE_BASE_TYPE(N) generates the call to the base class.
 * @references:
 *  [1]http://www.boost.org/libs/preprocessor/doc/topics/file_iteration.html
 *  [2]http://archives.free.net.ph/message/20060830.101840.d314c0fc.en.html
 */
#ifndef BOOST_PP_IS_ITERATING

    // sanity check for "named external arguments"
    #if !defined(BOOST_FORWARDER_CTOR_TEMPLATE_THIS_TYPE) \
     || !defined(BOOST_FORWARDER_CTOR_TEMPLATE_BASE_TYPE) \
    /**/
        #error "undefined macros, BOOST_FORWARDER_CTOR_TEMPLATE_{THIS,BASE}_TYPE."
    #endif   

     // initiate iteration...
    #define BOOST_PP_ITERATION_LIMITS \
        ( 0 \
        , ( (BOOST_FORWARDER_CTOR_TEMPLATE_MAX_ARITY) \
          ? (BOOST_FORWARDER_CTOR_TEMPLATE_MAX_ARITY) \
          : 4 \
          ) - 1 \
        ) \
        /**/
    #define BOOST_PP_FILENAME_1 BOOST_FORWARDER_CTOR_TEMPLATE_FILE_ITER()
    #include BOOST_PP_ITERATE()

    // automatically #undef "named external arguments"
    #undef BOOST_FORWARDER_CTOR_TEMPLATE_THIS_TYPE
    #undef BOOST_FORWARDER_CTOR_TEMPLATE_BASE_TYPE
#else // BOOST_PP_IS_ITERATING
  #define n BOOST_PP_ITERATION()

  #if n == 0
      BOOST_FORWARDER_CTOR_TEMPLATE_THIS_TYPE
        ( void
        )
  #else
     template <BOOST_PP_ENUM_PARAMS(n, typename U)>
     BOOST_FORWARDER_CTOR_TEMPLATE_THIS_TYPE
       ( BOOST_PP_ENUM_BINARY_PARAMS(n, U, & _)
       )
  #endif
       BOOST_FORWARDER_CTOR_TEMPLATE_BASE_TYPE(n)
       {
       }
       
  #undef n
#endif

