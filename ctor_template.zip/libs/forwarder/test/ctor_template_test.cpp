//test macros in ctor_template.hpp
//----------------------------
#include <boost/forwarder/ctor_template.hpp>
//delimit_macro_test_code
  template
  < typename Super
  , int=0
  >
  struct
sub
  : Super
{
#define  BOOST_FORWARDER_CTOR_TEMPLATE_THIS_TYPE sub
#define  BOOST_FORWARDER_CTOR_TEMPLATE_BASE_TYPE(N) : Super(BOOST_PP_ENUM_PARAMS(N, _))
#include BOOST_FORWARDER_CTOR_TEMPLATE_FILE_ITER()
};

  template
  < typename Super
  >
  struct
sub
  < Super
  , 1
  >
  : Super
{
#define  BOOST_FORWARDER_CTOR_TEMPLATE_THIS_TYPE sub
#define  BOOST_FORWARDER_CTOR_TEMPLATE_BASE_TYPE(N) : Super(BOOST_PP_ENUM_PARAMS(N, _))
#include BOOST_FORWARDER_CTOR_TEMPLATE_FILE_ITER()
};

  struct
int_float
{
    int_float(void);
    int_float(int);
    int_float(int,float);
    int_float(float);
};

#include <boost/forwarder/seq_to_identity_tuple.hpp>

  template
  < int I
  >
  struct
test
{  
    typedef sub<int_float,I> sub_int_float_type;
    sub_int_float_type my_void;
    sub_int_float_type my_int;
    sub_int_float_type my_int_float;
    test(void)
    : my_void()
    , my_int BOOST_FWD_SEQ_TO_IDENTITY_TUPLE
      ( (int(1))
      )
    , my_int_float BOOST_FWD_SEQ_TO_IDENTITY_TUPLE
      ( (int(1))
        (float(2.1))
      )
    {}
};

test<0> test0;
test<1> test1;
