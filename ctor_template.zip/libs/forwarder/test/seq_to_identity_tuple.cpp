#include "boost/forwarder/seq_to_identity_tuple.hpp"
//delimit_macro_test_code
BOOST_FWD_SEQ_TO_IDENTITY_TUPLE
( (a)
  (b)
  (c)
)
//Above should produce:
/*
(boost::forwarder::identity (a), boost::forwarder::identity (b),
  boost::forwarder::identity (c))
 */
