#if BOOST_VPP_VARIANT(0) < NUMBER_OF_FUNCTIONS

#define BOOST_VPP_DECIMAL_NUMBER BOOST_VPP_VARIANT(0)
#include <boost/vpp/to_decimal.hpp>
int BOOST_VPP_JOIN(function, BOOST_VPP_DECIMAL_NUMBER)
#undef BOOST_VPP_DECIMAL_NUMBER
(

 // top++;
#include <boost/vpp/allocate.hpp>

 // stack[top - 0] = 0;
#define BOOST_VPP_VALUE 0
#include <boost/vpp/reset/0.hpp>

 // NUMBER_OF_ARGUMENTS = stack[top - 1];
#define NUMBER_OF_ARGUMENTS BOOST_VPP_VARIANT(1)

#include "define_arguments.hpp"
#undef NUMBER_OF_ARGUMENTS

 // top--;
#include <boost/vpp/release.hpp>

 )
{
    // you can use both arg_class<BOOST_VPP_DECIMAL_NUMBER> or arg_class<BOOST_VPP_VARIANT(0)>, but complier would have clearer output if use BOOST_VPP_DECIMAL_NUMBER
#define BOOST_VPP_DECIMAL_NUMBER BOOST_VPP_VARIANT(0) * 2
#include <boost/vpp/to_decimal.hpp>
    return BOOST_VPP_DECIMAL_NUMBER;
#undef BOOST_VPP_DECIMAL_NUMBER
}

//stack[top - 0] = stack[top - 0] + 1;
#define BOOST_VPP_VALUE (BOOST_VPP_VARIANT(0) + 1)
#include <boost/vpp/reset/0.hpp>

#include "define_functions.hpp"
#endif
