#if BOOST_VPP_VARIANT(0) < NUMBER_OF_ARGUMENTS

#if BOOST_VPP_VARIANT(0) != 0
,
#endif

#define BOOST_VPP_DECIMAL_NUMBER BOOST_VPP_VARIANT(0)
#include <boost/vpp/to_decimal.hpp>
arg_class<BOOST_VPP_DECIMAL_NUMBER> BOOST_VPP_JOIN(arg_, BOOST_VPP_DECIMAL_NUMBER)
#undef BOOST_VPP_DECIMAL_NUMBER

#define BOOST_VPP_VALUE (BOOST_VPP_VARIANT(0) + 1)
#include <boost/vpp/reset/0.hpp>
#include "define_arguments.hpp"
#endif
