#include <boost/vpp.hpp>

template<int N>
class arg_class
{
};

// top++;
#include <boost/vpp/allocate.hpp>
// stack[top - 0] = 0;
#define BOOST_VPP_VALUE 0
#include <boost/vpp/reset/0.hpp>

#define NUMBER_OF_FUNCTIONS 20
#include "define_functions.hpp"

// top--;
#include <boost/vpp/release.hpp>


int main()
{
    return 0;
}
