


#define BOOST_VPP_POSITION 8
#include <boost/vpp/reset.hpp>
