


#define BOOST_VPP_POSITION 4
#include <boost/vpp/reset.hpp>
