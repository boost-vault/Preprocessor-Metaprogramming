


#define BOOST_VPP_POSITION 5
#include <boost/vpp/reset.hpp>
