


#define BOOST_VPP_POSITION 6
#include <boost/vpp/reset.hpp>
