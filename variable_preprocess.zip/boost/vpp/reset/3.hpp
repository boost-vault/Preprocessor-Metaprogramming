


#define BOOST_VPP_POSITION 3
#include <boost/vpp/reset.hpp>
