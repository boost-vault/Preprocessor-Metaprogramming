


#define BOOST_VPP_POSITION 7
#include <boost/vpp/reset.hpp>
