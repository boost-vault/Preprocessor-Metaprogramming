


#define BOOST_VPP_POSITION 0
#include <boost/vpp/reset.hpp>
