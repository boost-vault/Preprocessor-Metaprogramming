


#define BOOST_VPP_POSITION 9
#include <boost/vpp/reset.hpp>
