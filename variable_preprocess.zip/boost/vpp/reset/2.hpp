


#define BOOST_VPP_POSITION 2
#include <boost/vpp/reset.hpp>
