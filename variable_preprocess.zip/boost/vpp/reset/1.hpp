


#define BOOST_VPP_POSITION 1
#include <boost/vpp/reset.hpp>
