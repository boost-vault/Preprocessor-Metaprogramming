#if BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 0
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/0.hpp>
#include <boost/vpp/detail/set_by_index/0.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 0
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/0.hpp>
#include <boost/vpp/detail/set_by_index/0.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 1
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/1.hpp>
#include <boost/vpp/detail/set_by_index/1.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 2
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/2.hpp>
#include <boost/vpp/detail/set_by_index/2.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 3
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/3.hpp>
#include <boost/vpp/detail/set_by_index/3.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 4
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/4.hpp>
#include <boost/vpp/detail/set_by_index/4.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 5
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/5.hpp>
#include <boost/vpp/detail/set_by_index/5.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 6
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/6.hpp>
#include <boost/vpp/detail/set_by_index/6.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 7
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/7.hpp>
#include <boost/vpp/detail/set_by_index/7.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 8
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/8.hpp>
#include <boost/vpp/detail/set_by_index/8.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#elif BOOST_VPP_INDEX(BOOST_VPP_POSITION) == 9
#include <boost/vpp/detail/begin_set_value.hpp>
#include <boost/vpp/detail/clear_by_index/9.hpp>
#include <boost/vpp/detail/set_by_index/9.hpp>
#include <boost/vpp/detail/end_set_value.hpp>
#endif

