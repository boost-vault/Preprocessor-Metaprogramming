


#if (BOOST_VPP_VALUE & (1 << 0)) == 0
#define BOOST_VPP_INDEX_7_BIT_0 0
#else
#define BOOST_VPP_INDEX_7_BIT_0 1
#endif
#if (BOOST_VPP_VALUE & (1 << 1)) == 0
#define BOOST_VPP_INDEX_7_BIT_1 0
#else
#define BOOST_VPP_INDEX_7_BIT_1 1
#endif
#if (BOOST_VPP_VALUE & (1 << 2)) == 0
#define BOOST_VPP_INDEX_7_BIT_2 0
#else
#define BOOST_VPP_INDEX_7_BIT_2 1
#endif
#if (BOOST_VPP_VALUE & (1 << 3)) == 0
#define BOOST_VPP_INDEX_7_BIT_3 0
#else
#define BOOST_VPP_INDEX_7_BIT_3 1
#endif
#if (BOOST_VPP_VALUE & (1 << 4)) == 0
#define BOOST_VPP_INDEX_7_BIT_4 0
#else
#define BOOST_VPP_INDEX_7_BIT_4 1
#endif
#if (BOOST_VPP_VALUE & (1 << 5)) == 0
#define BOOST_VPP_INDEX_7_BIT_5 0
#else
#define BOOST_VPP_INDEX_7_BIT_5 1
#endif
#if (BOOST_VPP_VALUE & (1 << 6)) == 0
#define BOOST_VPP_INDEX_7_BIT_6 0
#else
#define BOOST_VPP_INDEX_7_BIT_6 1
#endif
#if (BOOST_VPP_VALUE & (1 << 7)) == 0
#define BOOST_VPP_INDEX_7_BIT_7 0
#else
#define BOOST_VPP_INDEX_7_BIT_7 1
#endif
#if (BOOST_VPP_VALUE & (1 << 8)) == 0
#define BOOST_VPP_INDEX_7_BIT_8 0
#else
#define BOOST_VPP_INDEX_7_BIT_8 1
#endif
#if (BOOST_VPP_VALUE & (1 << 9)) == 0
#define BOOST_VPP_INDEX_7_BIT_9 0
#else
#define BOOST_VPP_INDEX_7_BIT_9 1
#endif
#if (BOOST_VPP_VALUE & (1 << 10)) == 0
#define BOOST_VPP_INDEX_7_BIT_10 0
#else
#define BOOST_VPP_INDEX_7_BIT_10 1
#endif
#if (BOOST_VPP_VALUE & (1 << 11)) == 0
#define BOOST_VPP_INDEX_7_BIT_11 0
#else
#define BOOST_VPP_INDEX_7_BIT_11 1
#endif
#if (BOOST_VPP_VALUE & (1 << 12)) == 0
#define BOOST_VPP_INDEX_7_BIT_12 0
#else
#define BOOST_VPP_INDEX_7_BIT_12 1
#endif
#if (BOOST_VPP_VALUE & (1 << 13)) == 0
#define BOOST_VPP_INDEX_7_BIT_13 0
#else
#define BOOST_VPP_INDEX_7_BIT_13 1
#endif
#if (BOOST_VPP_VALUE & (1 << 14)) == 0
#define BOOST_VPP_INDEX_7_BIT_14 0
#else
#define BOOST_VPP_INDEX_7_BIT_14 1
#endif
#if (BOOST_VPP_VALUE & (1 << 15)) == 0
#define BOOST_VPP_INDEX_7_BIT_15 0
#else
#define BOOST_VPP_INDEX_7_BIT_15 1
#endif
#if (BOOST_VPP_VALUE & (1 << 16)) == 0
#define BOOST_VPP_INDEX_7_BIT_16 0
#else
#define BOOST_VPP_INDEX_7_BIT_16 1
#endif
#if (BOOST_VPP_VALUE & (1 << 17)) == 0
#define BOOST_VPP_INDEX_7_BIT_17 0
#else
#define BOOST_VPP_INDEX_7_BIT_17 1
#endif
#if (BOOST_VPP_VALUE & (1 << 18)) == 0
#define BOOST_VPP_INDEX_7_BIT_18 0
#else
#define BOOST_VPP_INDEX_7_BIT_18 1
#endif
#if (BOOST_VPP_VALUE & (1 << 19)) == 0
#define BOOST_VPP_INDEX_7_BIT_19 0
#else
#define BOOST_VPP_INDEX_7_BIT_19 1
#endif
#if (BOOST_VPP_VALUE & (1 << 20)) == 0
#define BOOST_VPP_INDEX_7_BIT_20 0
#else
#define BOOST_VPP_INDEX_7_BIT_20 1
#endif
#if (BOOST_VPP_VALUE & (1 << 21)) == 0
#define BOOST_VPP_INDEX_7_BIT_21 0
#else
#define BOOST_VPP_INDEX_7_BIT_21 1
#endif
#if (BOOST_VPP_VALUE & (1 << 22)) == 0
#define BOOST_VPP_INDEX_7_BIT_22 0
#else
#define BOOST_VPP_INDEX_7_BIT_22 1
#endif
#if (BOOST_VPP_VALUE & (1 << 23)) == 0
#define BOOST_VPP_INDEX_7_BIT_23 0
#else
#define BOOST_VPP_INDEX_7_BIT_23 1
#endif
#if (BOOST_VPP_VALUE & (1 << 24)) == 0
#define BOOST_VPP_INDEX_7_BIT_24 0
#else
#define BOOST_VPP_INDEX_7_BIT_24 1
#endif
#if (BOOST_VPP_VALUE & (1 << 25)) == 0
#define BOOST_VPP_INDEX_7_BIT_25 0
#else
#define BOOST_VPP_INDEX_7_BIT_25 1
#endif
#if (BOOST_VPP_VALUE & (1 << 26)) == 0
#define BOOST_VPP_INDEX_7_BIT_26 0
#else
#define BOOST_VPP_INDEX_7_BIT_26 1
#endif
#if (BOOST_VPP_VALUE & (1 << 27)) == 0
#define BOOST_VPP_INDEX_7_BIT_27 0
#else
#define BOOST_VPP_INDEX_7_BIT_27 1
#endif
#if (BOOST_VPP_VALUE & (1 << 28)) == 0
#define BOOST_VPP_INDEX_7_BIT_28 0
#else
#define BOOST_VPP_INDEX_7_BIT_28 1
#endif
#if (BOOST_VPP_VALUE & (1 << 29)) == 0
#define BOOST_VPP_INDEX_7_BIT_29 0
#else
#define BOOST_VPP_INDEX_7_BIT_29 1
#endif
#if (BOOST_VPP_VALUE & (1 << 30)) == 0
#define BOOST_VPP_INDEX_7_BIT_30 0
#else
#define BOOST_VPP_INDEX_7_BIT_30 1
#endif
#if (BOOST_VPP_VALUE & (1 << 31)) == 0
#define BOOST_VPP_INDEX_7_BIT_31 0
#else
#define BOOST_VPP_INDEX_7_BIT_31 1
#endif
