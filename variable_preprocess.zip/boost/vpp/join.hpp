#ifndef BOOST_VPP_JOIN
#define BOOST_VPP_JOIN_DIRECT(l, r) l##r
#define BOOST_VPP_JOIN(l, r) BOOST_VPP_JOIN_DIRECT(l, r)
#endif
