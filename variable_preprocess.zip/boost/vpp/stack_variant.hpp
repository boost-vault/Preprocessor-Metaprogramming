#ifndef BOOST_VPP_VARIANT

#define BOOST_VPP_TOP 0

#define BOOST_VPP_INDEX(pos) \
    BOOST_VPP_TOP - pos - 1

#define BOOST_VPP_VALUE 0
#include <boost/vpp/detail/set_by_index/0.hpp>
#include <boost/vpp/detail/set_by_index/1.hpp>
#include <boost/vpp/detail/set_by_index/2.hpp>
#include <boost/vpp/detail/set_by_index/3.hpp>
#include <boost/vpp/detail/set_by_index/4.hpp>
#include <boost/vpp/detail/set_by_index/5.hpp>
#include <boost/vpp/detail/set_by_index/6.hpp>
#include <boost/vpp/detail/set_by_index/7.hpp>
#include <boost/vpp/detail/set_by_index/8.hpp>
#include <boost/vpp/detail/set_by_index/9.hpp>
#undef BOOST_VPP_VALUE


#define BOOST_VPP_VARIANT(pos) \
    (\
    (BOOST_VPP_INDEX(pos) == 0) * (\
    (BOOST_VPP_INDEX_0_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_0_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_0_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_0_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_0_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_0_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_0_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_0_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_0_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_0_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_0_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_0_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_0_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_0_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_0_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_0_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_0_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_0_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_0_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_0_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_0_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_0_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_0_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_0_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_0_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_0_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_0_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_0_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_0_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_0_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_0_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_0_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 1) * (\
    (BOOST_VPP_INDEX_1_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_1_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_1_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_1_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_1_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_1_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_1_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_1_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_1_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_1_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_1_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_1_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_1_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_1_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_1_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_1_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_1_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_1_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_1_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_1_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_1_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_1_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_1_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_1_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_1_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_1_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_1_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_1_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_1_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_1_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_1_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_1_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 2) * (\
    (BOOST_VPP_INDEX_2_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_2_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_2_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_2_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_2_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_2_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_2_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_2_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_2_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_2_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_2_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_2_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_2_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_2_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_2_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_2_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_2_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_2_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_2_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_2_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_2_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_2_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_2_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_2_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_2_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_2_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_2_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_2_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_2_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_2_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_2_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_2_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 3) * (\
    (BOOST_VPP_INDEX_3_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_3_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_3_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_3_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_3_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_3_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_3_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_3_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_3_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_3_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_3_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_3_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_3_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_3_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_3_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_3_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_3_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_3_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_3_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_3_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_3_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_3_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_3_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_3_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_3_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_3_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_3_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_3_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_3_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_3_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_3_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_3_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 4) * (\
    (BOOST_VPP_INDEX_4_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_4_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_4_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_4_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_4_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_4_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_4_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_4_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_4_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_4_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_4_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_4_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_4_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_4_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_4_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_4_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_4_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_4_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_4_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_4_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_4_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_4_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_4_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_4_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_4_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_4_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_4_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_4_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_4_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_4_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_4_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_4_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 5) * (\
    (BOOST_VPP_INDEX_5_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_5_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_5_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_5_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_5_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_5_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_5_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_5_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_5_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_5_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_5_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_5_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_5_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_5_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_5_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_5_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_5_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_5_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_5_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_5_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_5_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_5_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_5_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_5_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_5_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_5_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_5_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_5_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_5_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_5_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_5_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_5_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 6) * (\
    (BOOST_VPP_INDEX_6_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_6_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_6_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_6_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_6_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_6_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_6_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_6_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_6_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_6_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_6_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_6_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_6_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_6_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_6_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_6_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_6_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_6_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_6_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_6_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_6_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_6_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_6_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_6_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_6_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_6_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_6_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_6_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_6_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_6_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_6_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_6_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 7) * (\
    (BOOST_VPP_INDEX_7_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_7_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_7_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_7_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_7_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_7_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_7_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_7_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_7_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_7_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_7_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_7_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_7_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_7_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_7_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_7_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_7_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_7_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_7_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_7_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_7_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_7_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_7_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_7_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_7_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_7_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_7_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_7_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_7_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_7_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_7_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_7_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 8) * (\
    (BOOST_VPP_INDEX_8_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_8_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_8_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_8_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_8_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_8_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_8_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_8_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_8_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_8_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_8_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_8_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_8_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_8_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_8_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_8_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_8_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_8_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_8_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_8_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_8_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_8_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_8_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_8_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_8_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_8_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_8_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_8_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_8_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_8_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_8_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_8_BIT_31 << 31) \
    ) \
    + (BOOST_VPP_INDEX(pos) == 9) * (\
    (BOOST_VPP_INDEX_9_BIT_0 << 0) \
    + (BOOST_VPP_INDEX_9_BIT_1 << 1) \
    + (BOOST_VPP_INDEX_9_BIT_2 << 2) \
    + (BOOST_VPP_INDEX_9_BIT_3 << 3) \
    + (BOOST_VPP_INDEX_9_BIT_4 << 4) \
    + (BOOST_VPP_INDEX_9_BIT_5 << 5) \
    + (BOOST_VPP_INDEX_9_BIT_6 << 6) \
    + (BOOST_VPP_INDEX_9_BIT_7 << 7) \
    + (BOOST_VPP_INDEX_9_BIT_8 << 8) \
    + (BOOST_VPP_INDEX_9_BIT_9 << 9) \
    + (BOOST_VPP_INDEX_9_BIT_10 << 10) \
    + (BOOST_VPP_INDEX_9_BIT_11 << 11) \
    + (BOOST_VPP_INDEX_9_BIT_12 << 12) \
    + (BOOST_VPP_INDEX_9_BIT_13 << 13) \
    + (BOOST_VPP_INDEX_9_BIT_14 << 14) \
    + (BOOST_VPP_INDEX_9_BIT_15 << 15) \
    + (BOOST_VPP_INDEX_9_BIT_16 << 16) \
    + (BOOST_VPP_INDEX_9_BIT_17 << 17) \
    + (BOOST_VPP_INDEX_9_BIT_18 << 18) \
    + (BOOST_VPP_INDEX_9_BIT_19 << 19) \
    + (BOOST_VPP_INDEX_9_BIT_20 << 20) \
    + (BOOST_VPP_INDEX_9_BIT_21 << 21) \
    + (BOOST_VPP_INDEX_9_BIT_22 << 22) \
    + (BOOST_VPP_INDEX_9_BIT_23 << 23) \
    + (BOOST_VPP_INDEX_9_BIT_24 << 24) \
    + (BOOST_VPP_INDEX_9_BIT_25 << 25) \
    + (BOOST_VPP_INDEX_9_BIT_26 << 26) \
    + (BOOST_VPP_INDEX_9_BIT_27 << 27) \
    + (BOOST_VPP_INDEX_9_BIT_28 << 28) \
    + (BOOST_VPP_INDEX_9_BIT_29 << 29) \
    + (BOOST_VPP_INDEX_9_BIT_30 << 30) \
    + (BOOST_VPP_INDEX_9_BIT_31 << 31) \
    ) \
    ) \
    /*BOOST_VPP_VARIANT*/
#endif
