#if BOOST_VPP_TOP == 1
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 0
#elif BOOST_VPP_TOP == 2
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 1
#elif BOOST_VPP_TOP == 3
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 2
#elif BOOST_VPP_TOP == 4
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 3
#elif BOOST_VPP_TOP == 5
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 4
#elif BOOST_VPP_TOP == 6
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 5
#elif BOOST_VPP_TOP == 7
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 6
#elif BOOST_VPP_TOP == 8
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 7
#elif BOOST_VPP_TOP == 9
#	undef BOOST_VPP_TOP
#	define BOOST_VPP_TOP 8
#else
#	error variant stack is already empty.
#endif
