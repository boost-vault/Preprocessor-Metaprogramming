#include <boost/vpp/detail/reset.hpp>
#undef BOOST_VPP_POSITION
#undef BOOST_VPP_VALUE
