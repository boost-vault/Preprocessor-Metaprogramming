#ifndef BOOST_VPP_HPP_
#define BOOST_VPP_HPP_

#include <boost/vpp/join.hpp>
#include <boost/vpp/stack_variant.hpp>

#endif
